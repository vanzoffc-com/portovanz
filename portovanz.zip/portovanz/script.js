// Music autoplay fix
window.addEventListener("load", () => {
  const music = document.getElementById("bg-music");
  music.play().catch(() => {
    console.log("Autoplay diblokir browser 😅");
  });
});

// Ganti section
function showSection(id) {
  document.querySelectorAll(".section").forEach(sec => sec.classList.remove("active"));
  document.getElementById(id).classList.add("active");
}